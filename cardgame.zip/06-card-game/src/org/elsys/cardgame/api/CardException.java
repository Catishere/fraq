package org.elsys.cardgame.api;

public class CardException extends RuntimeException {

	public CardException(String string) {
		super(string);
	}

}
