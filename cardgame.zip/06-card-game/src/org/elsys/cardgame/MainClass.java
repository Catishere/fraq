package org.elsys.cardgame;

import org.elsys.cardgame.api.Game;

public class MainClass {

	public static void main(String[] args) {
		Game.play(args[0]);
	}

}
