# Игри с карти

## Тестовете в `TestDeal.java` минават - 10 т.

## Тестовете в `TestTopBottomCard.java` минават  - 30 т.

## Тестовете в `TestSortShuffle.java` минават - 30 т.

## Тестовете в `TestPlayCardAndRemaining.javaч` минават - 30 т.

## Тестовете в `TestHighest.java` минават - 20 т.