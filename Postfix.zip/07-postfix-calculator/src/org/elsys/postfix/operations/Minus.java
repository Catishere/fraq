package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Minus extends AbstractOperation implements Operation {

	public Minus(Calculator calculator) {
		super(calculator, "-");
	}

	@Override
	public void calculate() {
		Double value1 = getCalculator().popValue();
		Double value2 = getCalculator().popValue();
		getCalculator().addValue(value2 - value1);
	}

}
