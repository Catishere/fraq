package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Rotate extends AbstractOperation implements Operation {

	public Rotate(Calculator calculator) {
		super(calculator, "rot3");
	}

	@Override
	public void calculate() {
		Double value1 = getCalculator().popValue();
		Double value2 = getCalculator().popValue();
		Double value3 = getCalculator().popValue();
		getCalculator().addValue(value2);
		getCalculator().addValue(value3);
		getCalculator().addValue(value1);
	}

}
