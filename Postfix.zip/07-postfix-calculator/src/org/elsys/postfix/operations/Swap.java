package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Swap extends AbstractOperation implements Operation {

	public Swap(Calculator calculator) {
		super(calculator, "swap");
	}

	@Override
	public void calculate() {
		Double value1 = getCalculator().popValue();
		Double value2 = getCalculator().popValue();
		getCalculator().addValue(value1);
		getCalculator().addValue(value2);
	}

}
