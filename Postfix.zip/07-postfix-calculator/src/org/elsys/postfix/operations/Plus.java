package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Plus extends AbstractOperation implements Operation {

	public Plus(Calculator calculator) {
		super(calculator, "+");
	}

	@Override
	public void calculate() {
		Double value1 = getCalculator().popValue();
		Double value2 = getCalculator().popValue();
		getCalculator().addValue(value1 + value2);
	}

}
