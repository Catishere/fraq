package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Cos extends AbstractOperation implements Operation {

	public Cos(Calculator calculator) {
		super(calculator, "cos");
	}

	@Override
	public void calculate() {
		Double value = getCalculator().popValue();
		double result = Math.cos(value);
		getCalculator().addValue(result);
	}

}
