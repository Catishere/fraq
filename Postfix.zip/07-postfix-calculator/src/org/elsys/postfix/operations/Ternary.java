package org.elsys.postfix.operations;

import org.elsys.postfix.Calculator;

public class Ternary extends AbstractOperation implements Operation {

	public Ternary(Calculator calculator) {
		super(calculator, "*-\\*");
	}

	@Override
	public void calculate() {
		Double value1 = getCalculator().popValue();
		Double value2 = getCalculator().popValue();
		Double value3 = getCalculator().popValue();
		
		Double result = value1 * value2 * -value3; 
		
		getCalculator().addValue(result);
	}

}
