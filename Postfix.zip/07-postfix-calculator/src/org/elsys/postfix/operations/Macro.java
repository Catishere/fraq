package org.elsys.postfix.operations;

import java.util.ArrayList;
import java.util.List;

import org.elsys.postfix.Calculator;

public class Macro extends AbstractOperation {

	private List<Operation> operations = new ArrayList<Operation>();
	
	public Macro(Calculator calculator, String name, List<Operation> macroInst) {
		super(calculator, name);
		operations = macroInst;
	}

	@Override
	public void calculate() {
		for (Operation operation : operations)
		{
			operation.calculate();
		}
		
	}
	
	public void addOperation(Operation op) {
		operations.add(op);
	}

}
