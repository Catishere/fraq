package org.subd.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLAccess {
        private Connection connect = null;
        private Statement statement = null;
        private PreparedStatement preparedStatement = null;
        private ResultSet resultSet = null;

        public void readDataBase() throws Exception {
                try {
                        Class.forName("com.mysql.jdbc.Driver");
                        connect = DriverManager
                                        .getConnection("jdbc:mysql://localhost/SUBD", "root", "root");

                        statement = connect.createStatement();
                        resultSet = statement.executeQuery("select * from teacher");
                        writeResultSet(resultSet);

                        preparedStatement = connect
                                        .prepareStatement("insert into teacher values (default, ?,?)");
 
                        preparedStatement.setString(1, "wladi");
                        preparedStatement.setString(2, "loshprogramist");
                        preparedStatement.executeUpdate();

                        preparedStatement = connect
                                        .prepareStatement("SELECT * from teacher");
                        resultSet = preparedStatement.executeQuery();
                        writeResultSet(resultSet);

                        // Remove again the insert comment
                        preparedStatement = connect
                        .prepareStatement("delete from teacher where name= ? ; ");
                        preparedStatement.setString(1, "mitov");
                        preparedStatement.executeUpdate();

                        resultSet = statement
                        .executeQuery("select * from teacher");

                } catch (Exception e) {
                        throw e;
                } finally {
                        close();
                }

        }


        private void writeResultSet(ResultSet resultSet) throws SQLException {
                // ResultSet is initially before the first data set
                while (resultSet.next()) {
                        // It is possible to get the columns via name
                        // also possible to get the columns via the column number
                        // which starts at 1
                        // e.g. resultSet.getSTring(2);
                		
                		String id = resultSet.getString("id");
                    	String name = resultSet.getString("name");
                        String role = resultSet.getString("role");
                        System.out.println("id: " + id);
                        System.out.println("Name: " + name);
                        System.out.println("Role: " + role);
                }
        }

        // You need to close the resultSet
        private void close() {
                try {
                        if (resultSet != null) {
                                resultSet.close();
                        }

                        if (statement != null) {
                                statement.close();
                        }

                        if (connect != null) {
                                connect.close();
                        }
                } catch (Exception e) {

                }
        }

}