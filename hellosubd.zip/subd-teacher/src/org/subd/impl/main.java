package org.subd.impl;
import org.subd.impl.MySQLAccess;	

public class main {
        public static void main(String[] args) throws Exception {
                MySQLAccess dao = new MySQLAccess();
                dao.readDataBase();
        }

}